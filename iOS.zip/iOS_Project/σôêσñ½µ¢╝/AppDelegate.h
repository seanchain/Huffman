//
//  AppDelegate.h
//  哈夫曼
//
//  Created by Sean Chain on 11/14/14.
//  Copyright (c) 2014 Sean Chain. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) NSMutableArray *files;
@property (strong, nonatomic) NSMutableArray *size;
@property (strong, nonatomic) NSMutableArray *compressedfiles;
@property (strong, nonatomic) NSMutableArray *compfilesize;

@end

