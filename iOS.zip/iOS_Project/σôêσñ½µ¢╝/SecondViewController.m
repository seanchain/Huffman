//
//  SecondViewController.m
//  哈夫曼
//
//  Created by Sean Chain on 11/14/14.
//  Copyright (c) 2014 Sean Chain. All rights reserved.
//

#import "SecondViewController.h"
#import "AppDelegate.h"
#import "FileDetail.h"
#import "CompContent.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

@synthesize table;

NSUInteger action;

AppDelegate *appdelegate;


-(long long) fileSizeAtPath:(NSString*) filePath{
    NSFileManager* manager = [NSFileManager defaultManager];
    if ([manager fileExistsAtPath:filePath]){
        return [[manager attributesOfItemAtPath:filePath error:nil] fileSize];
    }
    return 0;
}


- (void)refreshList
{
    appdelegate = [UIApplication sharedApplication].delegate;
    NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *compre = [docDir stringByAppendingPathComponent:@"compressed"];
    if (!compre) {
        [[NSFileManager defaultManager] createDirectoryAtPath:compre withIntermediateDirectories:YES attributes:nil error:nil];
    }
    NSMutableArray *filesarr = [[NSMutableArray alloc] init];
    filesarr = nil;
    filesarr = (NSMutableArray*)[[NSFileManager defaultManager] contentsOfDirectoryAtPath:compre error:nil];
    NSLog(@"%@", filesarr);
    appdelegate.compressedfiles = filesarr;
    NSLog(@"%@", appdelegate.compressedfiles);
    appdelegate.compfilesize = [[NSMutableArray alloc] init];
    for (NSString *filename in filesarr)
    {
        NSString *path = [compre stringByAppendingPathComponent:filename];
        NSLog(@"%@", path);
        long long size = [self fileSizeAtPath:path];
        NSNumber *num = [NSNumber numberWithLongLong:size];
        NSNumberFormatter* numberFormatter = [[NSNumberFormatter alloc] init];
        NSString *numstr = [numberFormatter stringFromNumber:num];
        numstr = [numstr stringByAppendingString:@" Bytes"];
        [appdelegate.compfilesize addObject:numstr];
    }
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.table.dataSource = self;
    self.table.delegate = self;
    [self refreshList];
    [self.table reloadData];
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    AppDelegate *app = [UIApplication sharedApplication].delegate;
    CompContent *cc = [self.storyboard instantiateViewControllerWithIdentifier:@"compressedfilecontent"];
    cc.editingIndexPath = indexPath;
    app.window.rootViewController = cc;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.table reloadData];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellID = @"cellID";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellID];
    }
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellID];
    NSInteger rowNO = indexPath.row;
    cell.textLabel.text = [appdelegate.compressedfiles objectAtIndex:rowNO];
    cell.layer.cornerRadius = 12;
    cell.layer.masksToBounds = YES;
    cell.detailTextLabel.text = [appdelegate.compfilesize objectAtIndex:rowNO];
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)edit:(UIBarButtonItem *)sender {
    [self.table setEditing: !self.table.editing animated:YES];
    if (self.table.editing) {
        self.editbn.title = @"完成";
    }
    else
        self.editbn.title = @"编辑";
}

- (UITableViewCellEditingStyle) tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}


- (void) tableView:(UITableView *)tableView commitEditingStyle:
(UITableViewCellEditingStyle)editingStyle
 forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        NSInteger rowNo = [indexPath row];
        // 从底层NSArray集合中删除指定数据项
        NSLog(@"-----");
        NSString *deletefilename = [appdelegate.compressedfiles objectAtIndex:rowNo];
        NSLog(@"*****");
        NSLog(@"%@", deletefilename);
        [appdelegate.compressedfiles removeObjectAtIndex: rowNo];
        // 从UITable程序界面上删除指定表格行。
        [tableView deleteRowsAtIndexPaths:[NSArray
                                           arrayWithObject:indexPath]
                         withRowAnimation:UITableViewRowAnimationAutomatic];
        NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
        NSString *comp = [docDir stringByAppendingPathComponent:@"compressed"];
        [[NSFileManager defaultManager] createDirectoryAtPath:comp withIntermediateDirectories:YES attributes:nil error:nil];
        NSString *deletepath = [comp stringByAppendingPathComponent:deletefilename];
        NSFileManager *manager = [NSFileManager defaultManager];
        [manager removeItemAtPath:deletepath error:nil];
        
    }
}




- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return appdelegate.compressedfiles.count;
}

- (NSString*)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return @"删除";
}

- (BOOL) tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

@end
