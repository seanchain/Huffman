//
//  CompContent.h
//  哈夫曼
//
//  Created by Sean Chain on 11/16/14.
//  Copyright (c) 2014 Sean Chain. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CompContent : UIViewController

@property NSIndexPath *editingIndexPath;
- (IBAction)decompress:(id)sender;

@property (weak, nonatomic) IBOutlet UITextView *codefield;

@end
