//
//  CompContent.m
//  哈夫曼
//
//  Created by Sean Chain on 11/16/14.
//  Copyright (c) 2014 Sean Chain. All rights reserved.
//

#import "CompContent.h"
#import "AppDelegate.h"
#import "FirstViewController.h"

@interface CompContent ()

@end

@implementation CompContent

@synthesize codefield;

AppDelegate *appdelegate;
NSUInteger rowNo;
NSString *filename;
NSString *filesize;
NSData *filecontent;


- (void)viewDidLoad {
    [super viewDidLoad];
    self.codefield.editable = NO;
    appdelegate = [UIApplication sharedApplication].delegate;
    rowNo = self.editingIndexPath.row;
    filename = [appdelegate.compressedfiles objectAtIndex:rowNo];
    filesize = [appdelegate.compfilesize objectAtIndex:rowNo];
    NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *comp = [docDir stringByAppendingPathComponent:@"compressed"];
    [[NSFileManager defaultManager] createDirectoryAtPath:comp withIntermediateDirectories:YES attributes:nil error:nil];
    NSString *filepath = [comp stringByAppendingPathComponent:filename];
    NSFileHandle *fh = [NSFileHandle fileHandleForReadingAtPath:filepath];
    NSData *content = [fh readDataToEndOfFile];
    NSString *contentstr = [[NSString alloc] initWithData:content encoding:NSISOLatin2StringEncoding];
    codefield.text = contentstr;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)decompress:(id)sender {
    NSLog(@"Hello");
    NSString *compfilename = [filename substringWithRange:NSMakeRange(0, filename.length - 4)];
    NSLog(@"%@", compfilename);
    NSString *myRequestString = [NSString stringWithFormat:@"compfilename=%@",compfilename];
    
    // Create Data from request
    NSData *myRequestData = [NSData dataWithBytes: [myRequestString UTF8String] length: [myRequestString length]];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL: [NSURL URLWithString: @"http://121.48.200.130/~seanchain/Huffman/decode.php"]];
    [request setHTTPMethod: @"POST"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"content-type"];
    [request setHTTPBody: myRequestData];
    NSData *returnData = [NSURLConnection sendSynchronousRequest: request returningResponse: nil error: nil];
    // Log Response
    NSString *response = [[NSString alloc] initWithBytes:[returnData bytes] length:[returnData length] encoding:NSUTF8StringEncoding];
        NSLog(@"%@", response);
        [self saveDecompressedFile:response];
}

- (void)saveDecompressedFile:(NSString*)content
{
    NSLog(@"%@", filename);
    NSString *newfilename = [filename substringWithRange:NSMakeRange(0, filename.length - 3)];
    newfilename = [newfilename stringByAppendingString:@"dec"];
    NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *uncomp = [docDir stringByAppendingPathComponent:@"uncompressedfile"];
    NSString *newdecodefile = [uncomp stringByAppendingPathComponent:newfilename];
    NSLog(@"*************");
    NSLog(@"%@", content);
    NSLog(@"#############");
    NSFileHandle *outfile = [NSFileHandle fileHandleForWritingAtPath:newdecodefile];
    [[NSFileManager defaultManager] createFileAtPath:newdecodefile contents:[content dataUsingEncoding:NSUTF8StringEncoding] attributes:nil];
    //[outfile truncateFileAtOffset:0];
    //[outfile writeData:[content dataUsingEncoding:NSUTF8StringEncoding]];
    [outfile closeFile];
    NSLog(@"file write successful");
}


@end
