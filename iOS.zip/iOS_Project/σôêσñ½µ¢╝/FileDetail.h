//
//  FileDetail.h
//  哈夫曼
//
//  Created by Sean Chain on 11/14/14.
//  Copyright (c) 2014 Sean Chain. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FileDetail : UIViewController <NSURLConnectionDataDelegate, NSURLConnectionDelegate>
@property (weak, nonatomic) NSIndexPath* editingIndexPath;
@property (weak, nonatomic) IBOutlet UITextView *textarea;
- (IBAction)save:(UIBarButtonItem *)sender;
- (IBAction)finishInput:(id)sender;
- (IBAction)compress:(UIBarButtonItem *)sender;
@property (weak, nonatomic) IBOutlet UIButton *savebutton;

@end
