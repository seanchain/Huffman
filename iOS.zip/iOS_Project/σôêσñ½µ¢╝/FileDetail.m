//
//  FileDetail.m
//  哈夫曼
//
//  Created by Sean Chain on 11/14/14.
//  Copyright (c) 2014 Sean Chain. All rights reserved.
//

#import "FileDetail.h"
#import "AppDelegate.h"
#import "FirstViewController.h"

@interface FileDetail ()

@end

@implementation FileDetail

@synthesize textarea;
@synthesize savebutton;


AppDelegate *appdelegate;
NSUInteger rowNo;
NSString *filename;
NSString *filesize;
NSData *filecontent;

- (void)viewDidLoad {
    [super viewDidLoad];
    appdelegate = [UIApplication sharedApplication].delegate;
    rowNo = self.editingIndexPath.row;
    filename = [appdelegate.files objectAtIndex:rowNo];
    filesize = [appdelegate.files objectAtIndex:rowNo];
    NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *uncomp = [docDir stringByAppendingPathComponent:@"uncompressedfile"];
    [[NSFileManager defaultManager] createDirectoryAtPath:uncomp withIntermediateDirectories:YES attributes:nil error:nil];
    NSString *filepath1 = [uncomp stringByAppendingPathComponent:filename];
    NSFileHandle *filehandle = [NSFileHandle fileHandleForUpdatingAtPath:filepath1];
    NSData *filecontent = [filehandle readDataToEndOfFile];
    NSString *filecontentstr = [[NSString alloc] initWithData:filecontent encoding:NSUTF8StringEncoding];
    self.textarea.text = filecontentstr;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


- (IBAction)inputfinished:(UIControl *)sender {
    [self.textarea resignFirstResponder];
}


- (IBAction)compress:(UIBarButtonItem *)sender {

    NSString *content = textarea.text;
    NSString *myRequestString = [NSString stringWithFormat:@"content=%@&filename=%@",content,filename];
    NSData *myRequestData = [myRequestString dataUsingEncoding:NSUTF8StringEncoding];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL: [NSURL URLWithString: @"http://121.48.200.130/~seanchain/Huffman/encode.php"]];
    [request setHTTPMethod: @"POST"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"content-type"];
    [request setHTTPBody: myRequestData];
    NSLog(@"%@", request);
    NSData *returnData = [NSURLConnection sendSynchronousRequest: request returningResponse: nil error: nil];
    // Log Response
    NSString *response = [[NSString alloc] initWithData:returnData encoding:NSISOLatin1StringEncoding];
    NSLog(@"%@", response);
    //NSLog(@"%@",response);
    NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *comp = [docDir stringByAppendingPathComponent:@"compressed"];
    NSFileHandle *fh = [NSFileHandle fileHandleForUpdatingAtPath:comp];
    if (!fh) {
        [[NSFileManager defaultManager] createDirectoryAtPath:comp withIntermediateDirectories:YES attributes:nil error:nil];
    }
    NSString *compressfile = [comp stringByAppendingPathComponent:[NSString stringWithFormat:@"%@_enc", filename]];
    NSLog(@"%@", compressfile);
    fh = [NSFileHandle fileHandleForUpdatingAtPath:compressfile];
    //NSFileHandle *fh = [NSFileHandle fileHandleForUpdatingAtPath:compressfile];
    [[NSFileManager defaultManager] createFileAtPath:compressfile contents:nil attributes:nil];
    [fh truncateFileAtOffset:0];
    [fh writeData:[response dataUsingEncoding:NSISOLatin1StringEncoding]];
    [fh closeFile];
}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *uncomp = [docDir stringByAppendingPathComponent:@"uncompressedfile"];
    [[NSFileManager defaultManager] createDirectoryAtPath:uncomp withIntermediateDirectories:YES attributes:nil error:nil];
    NSLog(@"%@", filename);
    NSString *filepath = [uncomp stringByAppendingPathComponent:filename];
    NSLog(@"%@", filepath);
    
    NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:filepath];
    if (!fh) {
        NSLog(@"File open error!!!");
    }
    NSString *textareastr = textarea.text;
    NSData *data = [textareastr dataUsingEncoding:NSUTF8StringEncoding];
    [fh truncateFileAtOffset:0];
    [fh writeData:data];
    [fh closeFile];
}




@end
