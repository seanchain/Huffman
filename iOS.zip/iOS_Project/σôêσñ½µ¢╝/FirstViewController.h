//
//  FirstViewController.h
//  哈夫曼
//
//  Created by Sean Chain on 11/14/14.
//  Copyright (c) 2014 Sean Chain. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController <UIAlertViewDelegate, UITableViewDataSource, UITableViewDelegate>
- (IBAction)add:(UIBarButtonItem *)sender;
- (IBAction)edit:(UIBarButtonItem *)sender;
@property (weak, nonatomic) IBOutlet UITableView *table;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *editbn;


@end

